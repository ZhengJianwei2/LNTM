clear,clc,close all;
run toolbox/vl_setup
addpath(genpath('./Utilities/'));
addpath(genpath('./Truncated/'));
addpath(genpath('./qualityassessment/'));
addpath(genpath('./nonlocal/'));
load WDC.mat
load R.mat;

S=Hw;

S=S(1:256,1:256,11:103);
S=double(S);
S=S/max(S(:));

 %%

sf = 4;
Z_ori = loadHSI(S);
sz(1)=size(S,1);sz(2)=size(S,2);

% kernel_type     =    {'Uniform_blur'};        % Uniform_blur or Gaussian_blur
kernel_type     =    {'Gaussian_blur'};
par = ParSet_new(sf,[sz(1),sz(2)],kernel_type);

s0=1;
 psf        =    fspecial('gaussian',7,2);
% psf        =    ones(sf)/(sf^2);
par.fft_B      =    psf2otf(psf,sz);
par.fft_BT     =    conj(par.fft_B);
par.H          =    @(z)H_z(z, par.fft_B, sf, sz,s0 );
par.HT         =    @(y)HT_y(y, par.fft_BT, sf, sz,s0);

RZ=ReshapeTo3D(Z_ori,[sz(1),sz(2),size(S,3)]);

%%
RZ2d = loadHSI(RZ);
rzSize = size(RZ);
sz = [rzSize(1),rzSize(2)];
X = par.H(RZ2d);         % X: low resolution HSI

%% GUSSIAN NOISE
gn=40;
for jj =1:size(X,1)
    X(jj,:) = awgn(X(jj,:),gn,'measured');  
end

P= R; 
P=P(:,1:end-10);
Y = P*RZ2d;              % Y: high spatial resolution RGB image

%% LNTM
% super-resolution
t1=clock;
[Z3d] = LNTM_truncated(sf,rzSize,par,X,Y,P,1 ); 
% sf: scaling factor/ rzSize: size of Z par: parameters / 
% X: low resolution HSI / Y: high spatial resolution RGB image /  P: Y = PZ / patch_size 
  
t2=clock;
s2=etime(t2,t1);
[PSNR1,RMSE1, ~, SAM1, ~,SSIM1,~,~] = quality_assessment(double(im2uint8(Z3d)), double(im2uint8(RZ)), 0, 1.0/sf);
 fprintf('PSNR= %.4f, RMSE=%.4f, SAM=%.4f, SSIM=%.4f\n', PSNR1, RMSE1,SAM1,SSIM1);

