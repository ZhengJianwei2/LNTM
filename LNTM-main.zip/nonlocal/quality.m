function  [PSNRvec,SSIMvec]=quality(OriData3,output_image) % OriData3 Ϊδ�������ĸɾ�ͼ��output_imageΪ�޸���ͼ��
    [m,n,p] = size(OriData3); 
    PSNRvector=zeros(1,p);   % P Ϊ�߹��׵Ĳ�����
    for i=1:1:p
        J=255*OriData3(:,:,i);

        I=255*output_image(:,:,i);

        PSNRvector(1,i)=PSNR(J,I,m,n);
    end
    %dlmwrite('PSNRvector.txt',PSNRvector,'delimiter','\t','newline','pc');
    % 
    PSNRvec = mean(PSNRvector);
    SSIMvector=zeros(1,p);
    for i=1:1:p
        J=255*OriData3(:,:,i);
    %     Jnoise=oriData3_noise(:,:,i);
        I=255*output_image(:,:,i); 
    %      [ SSIMnoisevector(1,i),ssim_map] = ssim(J,Jnoise);
          [ SSIMvector(1,i),ssim_map] = ssim(J,I);
    end
    SSIMvec=mean(SSIMvector);
    %dlmwrite('SSIMvector.txt',SSIMvector,'delimiter','\t','newline','pc');
%     fprintf( 'PSNR = %2.2f,SSIM = %2.4f\n', PSNRvec,SSIMvec )