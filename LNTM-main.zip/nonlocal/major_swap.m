

function q=major_swap(p,m,n)
% 1:(m*n) is swapped into [(n-1)*m+1:n*m , 1:(n-1)*m]
q=p([(n-1)*m+1:n*m 1:(n-1)*m]);