function idx=weight_ann_local2(data,num_s,max_compare)
% data is the patch set of an image. The local coordinates are already
% included

[m,n]=size(data);
kdtree = vl_kdtreebuild(data);

[idx, dist] = vl_kdtreequery(kdtree, data, data, 'NumNeighbors', num_s, 'MaxComparisons', max_compare);

