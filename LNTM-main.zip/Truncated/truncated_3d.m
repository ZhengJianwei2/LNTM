function [B]=truncated_3d(B,BB,idx,itr,ms2,B_blocks,bparams,P,rho,r)

for i=1:itr
        for mm=1:ms2
            num=idx(:,i);
        B_simpatch(:,mm,i)=BB(:,num(mm)); 
        end
            for ti=1:size(B,3)
                restack_B(:,:,ti)=B_simpatch((ti-1)*(P*P)+1:ti*(P*P),:,i);
            end
            [B2]=T_3d(restack_B,rho,r);
            for ti=1:size(B,3)
                repum1((ti-1)*(P*P)+1:ti*(P*P),:)=B2(:,:,ti);
            end
            repnum(:,:,i)=repum1;
end
 
    B_temp=zeros(size(BB));
    La=zeros(size(BB));
    temp=ones(size(BB,1),1);
    
    for kk=1:itr
        for nm=1:ms2
            num=idx(:,kk);
            temp1=repnum(:,nm,kk);
            B_temp(:,num(nm))=B_temp(:,num(nm))+temp1;
            La(:,num(nm))=La(:,num(nm))+temp;
        end
    end
    B_temp=B_temp./La;   
    B_temp=reshape(B_temp,size(B_blocks));
    B= JointBlocks2(B_temp, bparams); 