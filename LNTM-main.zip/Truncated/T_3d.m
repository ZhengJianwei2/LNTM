function [CC]=T_3d(data,rho,r) %% data is a 3D data, r is the truncated rank 

C=data;

C2 = Frontal2Lateral(C); % each lateral slice is a channel of the image

[n1,n2,n3]=size(C2);
k=min(n1,n2);
% % tic
[U1,S1,V1] = tsvd(C2,'econ');
r=min(r,size(S1,1));
% s = diag(S1(:,:,1));
% S1 = max(S1-tau,0);    
% S(:,:,i) = diag(s);
% S1= diag(s);
% toc
% C2 = tprod(tprod(U1,S1),tran(V1)); % C = U*S*V^*
% s1=diag(S1(:,:,5));
C1 = tprod(tprod(U1,S1(:,1:r,:)),tran(V1(:,1:r,:))); % C = U*S*V^*
% [C2,~,~] = Log_prox_tnn(C2,tau);
for i=1:size(S1,3)
         d(i,:) = diag(S1(:,:,i));
end

        U_G2 = U1(:, (r+1):k,:);
        V_G2 = V1(:, (r+1):k,:);
for j=1:size(S1,3)
        d_G2(:,:,j) = diag(d(j,(r+1):k));
end    
      % Prox Lqq
    t_Sharp = max(d_G2 - 1/rho, 0);
    C11 = tprod(tprod( U_G2 ,t_Sharp),tran(V_G2)); % C = U*S*V^*
    C2=C1+C11;
%         X_iPLUS = G1 + U_G2*diag(t_Sharp)*V_G2';

CC = Lateral2Frontal(C2); % each lateral slice is a channel of the image

% [PSNR,SSIM,SAM,MQ] = evaluate(CC,C_ori,n1,n2);
% p1(k)=PSNR;


%    
%         G1 = U(:, 1:r)*diag(d(1:r))*V(:, 1:r)';
%         U_G2 = U(:, (r+1):k);
%         V_G2 = V(:, (r+1):k);
%         d_G2 = d((r+1):k);
%       % Prox Lqq
%         t_Sharp = max(d_G2 - 1/rho, 0);
%         X_iPLUS = G1 + U_G2*diag(t_Sharp)*V_G2';
