# LNTM
This is the code for 'Hyperspectral and Multispectral Data Fusion via Joint Local-Nonlocal Manifold and Truncation Operator' 
